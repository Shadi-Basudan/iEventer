<?php
$out = shell_exec("python python.py");
?>
<?php
include 'config.php';
session_start();
$email = $_SESSION['email'];

$selectEvent = mysqli_query($conn, "SELECT * FROM event");
if (mysqli_num_rows($selectEvent) > 0) {
    $fetchDate = mysqli_fetch_assoc($selectEvent);
}
$now = time();
// $deleteEvent = mysqli_query($conn, "DELETE FROM `event` WHERE date ");

$SELECT = mysqli_query($conn, "SELECT * FROM `user` WHERE email = '$email'") or die('query failed');
if (mysqli_num_rows($SELECT) > 0) {
    $fetchUser = mysqli_fetch_assoc($SELECT);
}
$selectAgenda = mysqli_query($conn, "SELECT date_of_adding FROM `agenda` WHERE email = '$email' ORDER BY date_of_adding desc") or die('query failed');
$fetchAgenda = "";
while ($row = mysqli_fetch_array($selectAgenda)) {
    if (!empty($row)) {
        $fetchAgenda = $row[0];
        break;
    } else {
        $fetchAgenda = '';
    }
}

if (isset($_POST['add'])) {
    $username = $fetchUser['name'];
    $title = $_POST['title'];
    $category = $_POST['category'];
    $location = $_POST['location'];
    $date = $_POST['date'];
    $description = $_POST['desc'];

    // current time in (n/j/Y) format 
    $todaydate = date("n/j/Y", $now); // STRING
    $todaydatetoDate = strtotime($todaydate); // INTEGER

    // user date
    $formatdate = date("n/j/Y", strtotime($date)); // STRING - format the date that came from user input which will be placed into event table
    $formatdatetoDate = strtotime($formatdate); // INTEGER - the date is converted into datetime type 

    // current time in (Y-m-d h:i:s) format
    $currentDate = date('Y-m-d h:i:s', $now); // String - time of adding event time
    $currentDatetoDate = strtotime($currentDate); // INTEGER - the date is converted into datetime type 

    // from user actitivity
    $date_of_adding = $fetchAgenda; // date of last event was added which is that the last current time value was stored in agenda table
    $date_of_addingtoDate = strtotime($date_of_adding); // INTEGER - the date is converted into datetime type 

    // DB Queries
    $eventInsertQuery = "INSERT INTO `event`(`title`, `category`, `location`, `date`, `time`, `description`) 
    VALUES ('$title','$category','$location','$formatdate', '8:00 PM', '$description')";
    $agendaInsertQuery = "INSERT INTO `agenda`(`username`, `email`, `activity_name`, `date_of_adding`) 
    VALUES ('$username', '$email','$title','$currentDate')";

    // calculate the diifer between two integer dates 
    function diffInDays($currentDate, $targetDate)
    {
        $datediff = ($currentDate - $targetDate);
        return ($datediff / 86400);
    }

    // Check for the conflicts between the input date with the others in event table in row[date]
    function conflictChecker($connector, $insertEvent, $InsertAgenda, $selecter, $eventDate)
    {
        $matching = 0;
        // check the date over all rows in the event table, where is there is a match we will increment by 1
        try {
            while ($row = mysqli_fetch_array($selecter)) {
                if ($row['date'] == $eventDate) {
                    //try catch
                    $matching += 1;
                }
            }
            // After cheking we will insert the data if there is 0 matching dates with the input date in the table
            if ($matching == 0) {
                mysqli_query($connector, $insertEvent);
                mysqli_query($connector, $InsertAgenda);
            } else {
                echo "Dear student you are not allowed to make the event, there is conflict!";
            }
        } catch (Exception $err) {
            echo $err = "Dear student you are not allowed to make the event, there is conflict!";
        }
    }

    // must the all fields are filled
    if ((!empty($title)) && (!empty($category)) && (!empty($location)) && (!empty($formatdate)) && (!empty($description))) {
        // getting the difference between current date and user input to check if the date is passed or not!
        $prevDays = diffInDays($todaydatetoDate, $formatdatetoDate);
        if ($prevDays <= 0) {
            // When it is available date we will ensure if the date of adding by user is more than 1 day for scalability porpuses 
            if (!empty($date_of_adding)) {
                // Here we will ensure if the last adding by the user is acceed one single day
                $difference = diffInDays($currentDatetoDate, $date_of_addingtoDate);
                if ($difference >= 1) {
                    // We will call the conflict checker method to make sure if there is no conflict event by dates to make insert the data in DB
                    $conflictResult = conflictChecker($conn, $eventInsertQuery, $agendaInsertQuery, $selectEvent, $formatdate);
                } else {
                    echo "Dear student you are not allowed to make the event, you need to wait 24 hours elapsed from the last one you added!";
                }
            }
            // When the user is add an event for first time
            else {
                $conflictResult = conflictChecker($conn, $eventInsertQuery, $agendaInsertQuery, $selectEvent, $formatdate);
            }
        } else {
            echo "It is earlier date";
        }
    } else {
        echo "You must fill all the fields";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        h1 {
            font-size: 20px;
            font-weight: 700;
            color: rgb(104, 34, 34);
            text-align: center;
            text-transform: capitalize;
        }

        input,
        textarea {
            padding: 10px;
            outline: 0;
            border: 1px solid white;
            background: rgb(200, 200, 200);
            font-size: 15px;
            width: 100%;
        }

        .item1 {
            grid-area: left;
        }

        .item2 {
            grid-area: right;
        }

        .item3 {
            grid-area: bottom;
        }

        .flex {
            display: grid;
            grid-template-areas: 'left left left right right right'
                'bottom bottom bottom bottom bottom bottom';
            gap: 10px;
            padding: 10px;
        }

        .flex>div {
            padding: 20px 0;
        }


        .eventList {
            padding: 10px;
        }

        .eventTable {
            position: absolute;
            z-index: 2;
            left: 50%;
            transform: translate(-50%, -50%);
            align-items: center;
            width: 80%;
            height: 50px;
            max-width: 600px;
            border-collapse: collapse;
            border-spacing: 0;
            box-shadow: 0 2px 15px rgba(64, 64, 64, .7);
            border-radius: 12px 12px 0 0;
            overflow: hidden;
        }

        td,
        th {
            padding: 15px 20px;
            text-align: center;
        }

        th {
            background-color: rgb(104, 34, 34);
            color: #fafafa;
            font-family: 'Poppins', sans-serif;
            font-weight: 600;
            /* text-transform: uppercase; */
        }

        tr {
            width: 100%;
            background-color: #fafafa;
            font-family: 'Poppins', sans-serif;
        }

        tr:nth-child(even) {
            background-color: #eeeeee;
        }

        textarea {
            resize: none;
        }

        .addBtn {
            background: rgb(145, 48, 48);
            color: white;
            text-transform: capitalize;
            font-size: 17px;
            cursor: pointer;
        }

        .resetBtn {
            text-transform: capitalize;
            font-size: 17px;
            cursor: pointer;
        }

        .addBtn:hover {
            background: rgb(104, 34, 34);
            color: #fff;
        }

        .card-container {
            width: 100%;
            height: 100vh;
            display: flex;
            justify-content: space-around;
            align-items: center;
            flex-wrap: wrap;
        }

        .card-main {
            width: 22rem;
            height: 200px;
            border-radius: 1rem;
            position: relative;
            transform-style: preserve-3d;
            justify-content: center;
            transition: all .4s ease;
            align-items: center;
            margin: 1rem;
        }

        .card-main:hover {
            transform: rotateY(180deg);
        }

        .front-card {
            width: 100%;
            height: 100%;
            position: absolute;
            background-image: linear-gradient(to top right, rgb(124, 34, 34), rgb(134, 134, 134));
            border-radius: 1rem;
            backface-visibility: hidden;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 5px;
        }

        .back-card {
            width: 100%;
            height: 100%;
            position: absolute;
            border-radius: 1rem;
            backface-visibility: hidden;
            background-image: linear-gradient(to top right, rgb(124, 34, 34), rgb(134, 134, 134));
            transform: rotateY(180deg);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        .front-card p {
            margin-top: 1rem;
            font-size: .9rem;
            color: white;
        }

        h2 {
            color: white;
            font-weight: bold;
        }

        .back-light {
            color: #fff;
        }
    </style>
    <title>iEventer - Event</title>
</head>


<body>
    <header>
        <a href="#" class="logo">iEventer</a>
        <nav class="navigation">
            <a href="eventPage.php">Events</a>
            <a href="forumPage.php">Forums</a>
            <a href="meetingPage.php">Meetings</a>
        </nav>
        <img src="<?php echo $fetchUser['image']; ?>" id="user_pic" onclick="toggleMenu()">
        <div class="sub-menu_wrap" id="subMenu">
            <div class="sub-menu">
                <div class="user_info">
                    <h3><?php echo $fetchUser['name']; ?></h3>
                </div>
                <hr>
                <a href="iEventer.php" class="sub-menu_link">
                    <img src="images/home.png">
                    <p>Home</p>
                    <span>></span>
                </a>
                <a href="profile.php" class="sub-menu_link">
                    <img src="images/profile.png">
                    <p>Edit profile</p>
                    <span>></span>
                </a>
                <a href="logout.php" class="sub-menu_link">
                    <img src="images/logout.png">
                    <p class="outBtn">Logout</p>
                    <span>></span>
                </a>
            </div>
        </div>
    </header>
    <section>
        <div>
            <form method="POST" name="makeEvent" id="eventForm">
                <h1 style="font-size: 20px; font-weight: 700; color: rgb(104, 34, 34); text-align: center">Make event</h1>
                <br>
                <div class="flex">
                    <div class="item1">
                        <input placeholder="Write title" type="text" name="title"><br>
                        <input placeholder="Write category" type="text" name="category">
                    </div>
                    <div class="item2">
                        <input placeholder="Write date" type="date" name="date"><br>
                        <input placeholder="Write location" type="text" name="location">
                    </div>
                    <div class="item3">
                        <textarea placeholder="Write brief description within 200 letters" name="desc" cols="10" rows="5"></textarea>
                    </div>
                    <input type="submit" class="addBtn" id="add" name="add" value="Add event">
                    <input type="button" class="resetBtn" name="reset" value="Reset" onclick="resetFields();">
                </div>
            </form>
        </div>
    </section>
    <footer class="footer">
        <p class="footer-title"><span>Copyrights @ </span>Mohammed Aljabarti and Shadi Basudan</p>
    </footer>
</body>

<script>
    let subMenu = document.getElementById("subMenu");

    function toggleMenu() {
        subMenu.classList.toggle("open-menu");
    }
</script>

</html>