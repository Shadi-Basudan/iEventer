<?php
session_start();
?>
<html>

<head>
    <title>iEventer - Sign in</title>
    <link rel="stylesheet" href="style.css">
    <script type="text/javascript">
        function checkInfo() {
            document.getElementById("checking").innerHTML =
                '<h1 style="margin: 8px 0; width: 100%; border-radius: 5px; padding: 10px 15px; text-align: center; background-color: red; color: white;font-size:20">Email or password is incorrect</h1>';
        }
    </script>
</head>

<body>
    <header>
        <a href="#" class="logo">iEventer</a>
    </header>
    <div class="form-container">
        <form action="" method="POST" name="form" id="form">
            <div id="checking"></div>
            <input name="email" type="text" id="email" placeholder="Enter your email">
            <input name="pass" type="password" id="password" placeholder="Enter your password" />
            <input name="sub" type='submit' class="form-btn" value='Log in'></input>
            <p>Don't have an account? <a href="signup.php">register now</a></p>
            <p><a href="reset.php" style="color: blue;">Forgot password?</a></p>
        </form>
    </div>

    <?php
    include 'config.php';

    if (isset($_POST['sub'])) {
        $email = $_POST['email'];
        $pass = $_POST['pass'];
        $_SESSION['email'] = $email;
        $sql = "SELECT * FROM user";
        $loop = mysqli_query($conn, $sql);
        $check = false;
        while ($row = mysqli_fetch_array($loop)) {
            if ($row['email'] == $email && $row['password'] == $pass) {
                $check = true;
                $_SESSION['name'] = $row['name'];
                $_SESSION['image'] = $row['image'];
                break;
            }
        }
        if ($check == true) {
            header('Location:iEventer.php');
        }
        if ($check == false) {
            echo '<script type="text/javascript">',
            'checkInfo();',
            '</script>';
        }
    }

    ?>
    <footer class="footer">
        <p class="footer-title"><span>Copyrights @ </span>Mohammed Aljabarti and Shadi Basudan</p>
    </footer>
</body>

</html>