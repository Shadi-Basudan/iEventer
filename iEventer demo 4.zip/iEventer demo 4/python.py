import sys
import glob
import requests as req
import easyocr
import cv2
import mysql.connector
import configparser
import tweepy
import datetime
# Connection
db = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="",
    database="iEventer"
)
mycursor = db.cursor()
selectQuery = "SELECT date FROM `event`"


# Configration
config = configparser.ConfigParser()
config.read('configTwitterAPI.ini')

api_key = config['twitter']['api_key']
api_key_secret = config['twitter']['api_key_secret']

access_token = config['twitter']['access_token']
access_token_secret = config['twitter']['access_token_secret']

# Authentication
auth = tweepy.OAuthHandler(api_key, api_key_secret)
auth.set_access_token(access_token, access_token_secret)

api = tweepy.API(auth)

# Fetching the user tweets
user = 'iEventer_'
limit = 100

tweets = api.user_timeline(
    screen_name=user, count=limit, tweet_mode='extended')


def findValue(fullString):
    delimeter = ': '
    fullString = fullString.rstrip('\n')
    value = fullString[fullString.index(delimeter)+1:]
    return value


def storeInfo(title, category, location, date, description):
    mycursor.execute(selectQuery)
    table = mycursor.fetchall()
    # input
    eventdate = date.replace(" ", "")
    currentdate = datetime.datetime.today()
    # format
    format = datetime.datetime.strftime(currentdate, "%#m/%#d/%Y")
    # string to date
    formattoDate = datetime.datetime.strptime(format, "%m/%d/%Y")
    eventtoDate = datetime.datetime.strptime(eventdate, "%m/%d/%Y")
    # difference between input date in integer
    out = (formattoDate - eventtoDate).days
    if (out >= 1):
        print("")
    else:
        matching = 0
        dateUser = "('"+date+"',)"
        for row in table:
            text = str(row)
            if (text == dateUser):
                matching += 1
        if (matching == 0):
            mycursor.execute(
                "INSERT INTO `event` (`id`, `title`, `category`, `location`, `date`, `time`,`description`) VALUES ('NULL', '"+title+"', '"+category+"', '"+location+"', '"+eventdate+"', '8:00 PM', '"+description+"');")
            db.commit()
    truncater()


def truncater():
    f1 = open('tweet_text\get.txt', 'r+')
    f1.truncate(0)
    f2 = open('tweet_text\store.txt', 'r+')
    f2.truncate(0)


def filter():
    with open("tweet_text\get.txt", "r") as file:
        for line in file:
            if "Title" in line:
                title = findValue(line)
            if "Category" in line:
                category = findValue(line)
            if "Location" in line:
                location = findValue(line)
            if "Date" in line:
                date = findValue(line)
            if "Description" in line:
                description = findValue(line)
        storeInfo(title, category, location, date, description)


def formatter():
    f = open("tweet_text\get.txt", "a")
    with open("tweet_text\store.txt", "r") as file:
        for line in file:
            line = line.replace('Title', '\nTitle')
            line = line.replace('Category', '\nCategory')
            line = line.replace('Location', '\nLocation')
            line = line.replace('Date', '\nDate')
            line = line.replace('Description', '\nDescription')
            f.write(line)
    f.close()


def writeTextInfo(text):
    f = open("tweet_text\store.txt", "a")
    f.write(''.join(text))
    f.write('\n')
    f.write('\n')
    f.close()


def OCR():
    folderPath = 'twitter_images\iEventer_'
    filePaths = list(glob.glob("{0}\*".format(folderPath)))
    for fPath in filePaths:
        img = cv2.imread(fPath)
        reader = easyocr.Reader(['en'], gpu=False)
        results = reader.readtext(img)
        text = ''
        for result in results:
            text += result[1] + ' '
        textProccessing(text)


def getTweetMediaURL(tweets):
    tweets_with_media = set()
    for tweet in tweets:
        media = tweet.entities.get('media', [])
        if (len(media) > 0):
            tweets_with_media.add(media[0]['media_url'])
            sys.stdout.write("\rMedia Links fetched: %d" %
                             len(tweets_with_media))
            sys.stdout.flush()
            print("\n")
            downloadFiles(tweets_with_media)
    return tweets_with_media


def downloadFiles(media_url):
    i = 0
    for url in media_url:
        var = req.get(url)
        with open('twitter_images\iEventer_\photo'+str(i)+'.jpg', 'wb') as file:
            file.write(var.content)
        i += 1


def textProccessing(text):
    writeTextInfo(text)
    formatter()
    filter()


def run():
    data = []
    i = 0
    text = ''
    getTweetMediaURL(tweets)
    OCR()
    for text_tweet in tweets:
        data.append([text_tweet.full_text])
        text = data[i]
        i += 1
        info = str(text)
        if not info.__contains__("https"):
            textProccessing(text)


run()
