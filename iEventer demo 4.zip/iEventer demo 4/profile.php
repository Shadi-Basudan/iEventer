<?php
include 'config.php';
session_start();
$email = $_SESSION['email'];
if (isset($_POST['sub'])) {
    $username = $_POST['update_name'];
    $newpassword = $_POST['new_pass'];
    $department = $_POST['department'];
    $usergender = $_POST['usergender'];
    $filename = $_FILES["file"]["name"];
    $tempname = $_FILES["file"]["tmp_name"];
    $folder = "images/" . $filename;
    move_uploaded_file($filename, $folder);
    if ((!empty($username))) {
        $updatename =  "UPDATE user SET name = '$username' WHERE email ='$email'";
        mysqli_query($conn, $updatename) or die('query failed');
    }
    if ((!empty($newpassword))) {
        $updatepass = "UPDATE user SET password = '$newpassword' WHERE email ='$email'";
        mysqli_query($conn, $updatepass) or die('query failed');
    }
    if ((!empty($usergender))) {
        $updategender = "UPDATE user SET gender = '$usergender' WHERE email ='$email'";
        mysqli_query($conn, $updategender) or die('query failed');
    }
    if ((!empty($department))) {
        $updatedep = "UPDATE user SET department = '$department' WHERE email ='$email'";
        mysqli_query($conn, $updatedep) or die('query failed');
    }
    if ((!empty($folder))) {
        if ((!empty($filename))) {
            $updateimage = "UPDATE user SET image = '$folder' WHERE email ='$email'";
            mysqli_query($conn, $updateimage) or die('query failed');
        }
    }
}
?>
<?php
$SELECT = mysqli_query($conn, "SELECT * FROM `user` WHERE email = '$email'") or die('query failed');
if (mysqli_num_rows($SELECT) > 0) {
    $fetch = mysqli_fetch_assoc($SELECT);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https //cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/2420bc253e.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <script>
        function checkInfo() {
            var pw = document.getElementById("pw").value;
            var pass_val = /^[A-Za-z]\w{7,14}$/;
            if (!(pw == '')) {
                if (!(pw.length >= 8 && pw.match(pass_val))) {
                    document.getElementById("sub").style.display = "none";
                    document.getElementById("checking").innerHTML = '<h1 style="margin: 8px 0; width: 100%; border-radius: 5px; padding: 10px 15px; text-align: center; background-color: red; color: white;font-size:20">invalid password</h1>';

                } else {
                    document.getElementById("sub").style.display = "block";
                }
            }
            document.getElementById("sub").style.display = "block";
        }
    </script>
    </style>
    <style>
        .upload img {
            border-radius: 50%;
            border: 8px solid #dcdcdc;
            width: 225px;
            height: 225px;
        }

        #uploadImage {
            position: relative;
            bottom: 0;
            right: 0;
            background: rgb(23, 23, 131);
            ;
            width: 32px;
            height: 32px;
            line-height: 33px;
            text-align: center;
            border-radius: 50%;
            overflow: hidden;
            cursor: pointer;
        }

        #icon {
            color: white;
        }

        #file {
            position: relative;
            transform: scale(2);
            opacity: 0;
        }



        body {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        input {
            padding: 5px;
        }

        div {
            margin: 5px;
        }

        .form-contaier {
            display: grid;
            grid-template-columns: 1fr 1fr;
            grid-template-rows: 1fr 1fr 1fr;
            grid-template-areas: "checking checking" "upload information" "buttons buttons";
        }

        .checking {
            grid-area: checking;
        }

        .upload {
            grid-area: upload;
        }

        .information {
            grid-area: information;
        }

        .buttons {
            grid-area: buttons;
        }

        footer {
            margin-top: auto;
        }
    </style>
    <title>iEventer - Edit profile</title>
    <script>
        function myFunction() {
            document.getElementById("myDropdown").classList.toggle("show");
        }
        window.onclick = function(event) {
            if (!event.target.matches('.dropbtn')) {
                var dropdowns = document.getElementsByClassName("dropdown-content");
                var i;
                for (i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');
                    }
                }
            }
        }
    </script>

<body>
    <header>
        <a href="iEventer.php" class="logo">iEventer</a>
        <nav class="navigation">
            <a href="eventPage.php">Events</a>
            <a href="forumPage.php">Forums</a>
            <a href="meetingPage.php">Meetings</a>
        </nav>
        <img src="<?php echo $fetch['image']; ?>" id="user_pic" onclick="toggleMenu()">
        <div class="sub-menu_wrap" id="subMenu">
            <div class="sub-menu">
                <div class="user_info">
                    <h3><?php echo $fetch['name']; ?></h3>
                </div>
                <hr>

                <a href="iEventer.php" class="sub-menu_link">
                    <img src="images/home.png">
                    <p>Home</p>
                    <span>></span>
                </a>
                <a href="logout.php" class="sub-menu_link">
                    <img src="images/logout.png">
                    <p class="outBtn">Logout</p>
                    <span>></span>
                </a>
            </div>
        </div>
    </header>

    <section>
        <div class="form contaier">
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="checking">
                    <div id="checking"></div>
                </div>
                <div class="upload">
                    <img src="<?php echo $fetch['image']; ?>">
                    <div class="rightround" id="uploadImage">
                        <i class="fa-solid fa-camera" id="icon"></i>
                        <input type="file" name="file" id="file" accept="image/jpg, image/jpeg, image/png">
                    </div>
                </div>
                <div class="information">
                    <div>
                        <input type="text" name="update_name" size="50px" value="<?php echo $fetch['name']; ?>">
                    </div>
                    <div>
                        <input type="text" name="email" size="50px" value="<?php echo $fetch['email']; ?>" disabled="disabled">
                    </div>

                    <div>
                        <input type="password" name="new_pass" size="50px" id="pw" placeholder="Enter new password">
                    </div>
                    <div><select name="department">
                            <option value="0">Select department</option>
                            <option style="font-weight: bold" value="Information Technology">Information Technology</option>
                            <option style="font-weight: bold" value="Information System">Information System</option>
                            <option style="font-weight: bold" value="Computer Science">Computer Science</option>
                        </select>
                    </div>
                    <div><select name="usergender">
                            <option value="0">Select gender</option>
                            <option style="font-weight: bold" value="Male">Male</option>
                            <option style="font-weight: bold" value="Female">Female</option>
                        </select>
                    </div>
                </div>
                <div class="buttons">
                    <input type="button" value="check" name="check" onclick="checkInfo()" required class="btn">
                    <input style="display:none" type="submit" id="sub" name="sub" class="form-btn" value="update profile" />
                </div>
            </form>
        </div>
    </section>

    <div>

    </div>
    </div>
    <footer class="footer">
        <p class="footer-title"><span>Copyrights @ </span>Mohammed Aljabarti and Shadi Basudan</p>
    </footer>
</body>
<script>
    let subMenu = document.getElementById("subMenu");

    function toggleMenu() {
        subMenu.classList.toggle("open-menu");
    }
</script>

</html>